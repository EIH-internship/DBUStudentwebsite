// Global variables for user management and system state
let currentUser = null;
let hasVoted = false;
let isIdVerified = false;
let complaintCounter = 1000;
let joinRequestCounter = 1000;
let electionActive = true;
let selectedCandidateForVoting = null;
let selectedClubForJoining = null;

// User roles and permissions
const USER_ROLES = {
    ADMIN: 'admin',
    COUNCIL_PRESIDENT: 'council_president',
    BRANCH_MEMBER: 'branch_member',
    CLUB_PRESIDENT: 'club_president',
    STUDENT: 'student'
};

// Predefined users for demonstration - FIXED LOGIN SYSTEM
const SYSTEM_USERS = {
    // Admin accounts
    'admin001': { 
        password: 'admin123', 
        role: USER_ROLES.ADMIN, 
        name: 'System Administrator',
        permissions: ['all']
    },
    
    // Council President
    'president001': { 
        password: 'president123', 
        role: USER_ROLES.COUNCIL_PRESIDENT, 
        name: 'Council President',
        permissions: ['manage_all_branches', 'approve_all', 'view_all_complaints', 'election_control']
    },
    
    // Branch Members - Each branch has specific responsibilities
    'academic001': { 
        password: 'academic123', 
        role: USER_ROLES.BRANCH_MEMBER, 
        name: 'Academic Affairs Representative',
        branch: 'academic',
        permissions: ['manage_academic_affairs', 'submit_reports', 'create_proposals']
    },
    'welfare001': { 
        password: 'welfare123', 
        role: USER_ROLES.BRANCH_MEMBER, 
        name: 'Student Welfare Representative',
        branch: 'welfare',
        permissions: ['manage_student_welfare', 'submit_reports', 'create_proposals']
    },
    'sports001': { 
        password: 'sports123', 
        role: USER_ROLES.BRANCH_MEMBER, 
        name: 'Sports & Recreation Representative',
        branch: 'sports',
        permissions: ['manage_sports_recreation', 'submit_reports', 'create_proposals']
    },
    'cultural001': { 
        password: 'cultural123', 
        role: USER_ROLES.BRANCH_MEMBER, 
        name: 'Cultural Affairs Representative',
        branch: 'cultural',
        permissions: ['manage_cultural_affairs', 'submit_reports', 'create_proposals']
    },
    'dining001': { 
        password: 'dining123', 
        role: USER_ROLES.BRANCH_MEMBER, 
        name: 'Dining Services Representative',
        branch: 'dining',
        permissions: ['manage_dining_services', 'submit_reports', 'create_proposals']
    },
    'clubs001': { 
        password: 'clubs123', 
        role: USER_ROLES.BRANCH_MEMBER, 
        name: 'Clubs & Associations Representative',
        branch: 'clubs',
        permissions: ['manage_clubs_associations', 'submit_reports', 'create_proposals']
    },
    'general001': { 
        password: 'general123', 
        role: USER_ROLES.BRANCH_MEMBER, 
        name: 'General Services Representative',
        branch: 'general',
        permissions: ['manage_general_services', 'submit_reports', 'create_proposals']
    },
    'secretary001': { 
        password: 'secretary123', 
        role: USER_ROLES.BRANCH_MEMBER, 
        name: 'Secretary Office Representative',
        branch: 'secretary',
        permissions: ['manage_documentation', 'submit_reports', 'create_proposals']
    },
    'speaker001': { 
        password: 'speaker123', 
        role: USER_ROLES.BRANCH_MEMBER, 
        name: 'Speaker Office Representative',
        branch: 'speaker',
        permissions: ['manage_communications', 'submit_reports', 'create_proposals']
    },
    'vice001': { 
        password: 'vice123', 
        role: USER_ROLES.BRANCH_MEMBER, 
        name: 'Vice President',
        branch: 'vice',
        permissions: ['assist_president', 'submit_reports', 'create_proposals']
    },
    
    // Club Presidents
    'club_debate001': { 
        password: 'debate123', 
        role: USER_ROLES.CLUB_PRESIDENT, 
        name: 'Debate Club President',
        club: 'debate',
        permissions: ['manage_club_members', 'create_events', 'club_reports']
    },
    'club_drama001': { 
        password: 'drama123', 
        role: USER_ROLES.CLUB_PRESIDENT, 
        name: 'Drama Club President',
        club: 'drama',
        permissions: ['manage_club_members', 'create_events', 'club_reports']
    },
    'club_music001': { 
        password: 'music123', 
        role: USER_ROLES.CLUB_PRESIDENT, 
        name: 'Music Club President',
        club: 'music',
        permissions: ['manage_club_members', 'create_events', 'club_reports']
    },
    'club_sports001': { 
        password: 'sports123', 
        role: USER_ROLES.CLUB_PRESIDENT, 
        name: 'Sports Club President',
        club: 'sports',
        permissions: ['manage_club_members', 'create_events', 'club_reports']
    },
    'club_science001': { 
        password: 'science123', 
        role: USER_ROLES.CLUB_PRESIDENT, 
        name: 'Science Club President',
        club: 'science',
        permissions: ['manage_club_members', 'create_events', 'club_reports']
    },
    'club_literature001': { 
        password: 'literature123', 
        role: USER_ROLES.CLUB_PRESIDENT, 
        name: 'Literature Club President',
        club: 'literature',
        permissions: ['manage_club_members', 'create_events', 'club_reports']
    },
    'club_photography001': { 
        password: 'photography123', 
        role: USER_ROLES.CLUB_PRESIDENT, 
        name: 'Photography Club President',
        club: 'photography',
        permissions: ['manage_club_members', 'create_events', 'club_reports']
    },
    'club_volunteer001': { 
        password: 'volunteer123', 
        role: USER_ROLES.CLUB_PRESIDENT, 
        name: 'Volunteer Club President',
        club: 'volunteer',
        permissions: ['manage_club_members', 'create_events', 'club_reports']
    },
    'club_business001': { 
        password: 'business123', 
        role: USER_ROLES.CLUB_PRESIDENT, 
        name: 'Business Club President',
        club: 'business',
        permissions: ['manage_club_members', 'create_events', 'club_reports']
    },
    'club_tech001': { 
        password: 'tech123', 
        role: USER_ROLES.CLUB_PRESIDENT, 
        name: 'Technology Club President',
        club: 'tech',
        permissions: ['manage_club_members', 'create_events', 'club_reports']
    },
    
    // Sample students
    'DBU2024001': { 
        password: 'student123', 
        role: USER_ROLES.STUDENT, 
        name: 'John Doe',
        department: 'Computer Science',
        permissions: ['vote', 'submit_complaint', 'join_clubs']
    },
    'DBU2024002': { 
        password: 'student456', 
        role: USER_ROLES.STUDENT, 
        name: 'Jane Smith',
        department: 'Engineering',
        permissions: ['vote', 'submit_complaint', 'join_clubs']
    }
};

// Club information
const CLUBS_DATA = {
    debate: {
        name: 'Debate Club',
        icon: '🎤',
        description: 'Develop your public speaking and argumentation skills',
        members: 45,
        events: 12,
        president: 'club_debate001',
        branch: 'clubs',
        pendingRequests: []
    },
    drama: {
        name: 'Drama Club',
        icon: '🎭',
        description: 'Express yourself through theatrical performances',
        members: 38,
        events: 8,
        president: 'club_drama001',
        branch: 'clubs',
        pendingRequests: []
    },
    music: {
        name: 'Music Club',
        icon: '🎵',
        description: 'Create and perform music with fellow students',
        members: 52,
        events: 15,
        president: 'club_music001',
        branch: 'cultural',
        pendingRequests: []
    },
    sports: {
        name: 'Sports Club',
        icon: '⚽',
        description: 'Stay active and compete in various sports',
        members: 78,
        events: 20,
        president: 'club_sports001',
        branch: 'sports',
        pendingRequests: []
    },
    science: {
        name: 'Science Club',
        icon: '🔬',
        description: 'Explore scientific discoveries and innovations',
        members: 41,
        events: 10,
        president: 'club_science001',
        branch: 'academic',
        pendingRequests: []
    },
    literature: {
        name: 'Literature Club',
        icon: '📚',
        description: 'Discuss books and creative writing',
        members: 33,
        events: 7,
        president: 'club_literature001',
        branch: 'cultural',
        pendingRequests: []
    },
    photography: {
        name: 'Photography Club',
        icon: '📸',
        description: 'Capture moments and learn photography techniques',
        members: 29,
        events: 9,
        president: 'club_photography001',
        branch: 'cultural',
        pendingRequests: []
    },
    volunteer: {
        name: 'Volunteer Club',
        icon: '🤝',
        description: 'Make a difference in the community',
        members: 56,
        events: 18,
        president: 'club_volunteer001',
        branch: 'welfare',
        pendingRequests: []
    },
    business: {
        name: 'Business Club',
        icon: '💼',
        description: 'Learn entrepreneurship and business skills',
        members: 47,
        events: 11,
        president: 'club_business001',
        branch: 'general',
        pendingRequests: []
    },
    tech: {
        name: 'Technology Club',
        icon: '💻',
        description: 'Explore latest technology trends and coding',
        members: 64,
        events: 16,
        president: 'club_tech001',
        branch: 'academic',
        pendingRequests: []
    }
};

// Branch information
const BRANCHES_DATA = {
    academic: {
        name: 'Academic Affairs',
        icon: '📚',
        description: 'Handles academic policies, curriculum feedback, and student academic concerns',
        responsibilities: ['Academic Policy Review', 'Curriculum Feedback', 'Grade Appeals', 'Academic Support']
    },
    welfare: {
        name: 'Student Welfare',
        icon: '🏥',
        description: 'Focuses on student health, accommodation, and general welfare issues',
        responsibilities: ['Health Services', 'Accommodation', 'Welfare Support', 'Emergency Assistance']
    },
    sports: {
        name: 'Sports & Recreation',
        icon: '⚽',
        description: 'Organizes sports events, recreational activities, and fitness programs',
        responsibilities: ['Sports Events', 'Fitness Programs', 'Recreation Activities', 'Sports Facilities']
    },
    cultural: {
        name: 'Cultural Affairs',
        icon: '🎭',
        description: 'Promotes cultural diversity, organizes festivals, and cultural exchange programs',
        responsibilities: ['Cultural Events', 'Festivals', 'Cultural Exchange', 'Arts Programs']
    },
    dining: {
        name: 'Dining Services',
        icon: '🍽️',
        description: 'Manages dining hall operations, meal plans, and food quality standards',
        responsibilities: ['Dining Operations', 'Meal Plans', 'Food Quality', 'Nutrition Programs']
    },
    clubs: {
        name: 'Clubs & Associations',
        icon: '🏛️',
        description: 'Oversees all student clubs, societies, and extracurricular organizations',
        responsibilities: ['Club Oversight', 'New Club Registration', 'Club Events', 'Inter-Club Coordination']
    },
    general: {
        name: 'General Services',
        icon: '🔧',
        description: 'Handles general student services, facilities, and campus improvements',
        responsibilities: ['Campus Facilities', 'General Services', 'Infrastructure', 'Maintenance']
    },
    secretary: {
        name: 'Secretary Office',
        icon: '📋',
        description: 'Manages documentation, communications, and administrative tasks',
        responsibilities: ['Documentation', 'Communications', 'Meeting Minutes', 'Administrative Tasks']
    },
    speaker: {
        name: 'Speaker Office',
        icon: '🎙️',
        description: 'Manages council meetings, parliamentary procedures, and official communications',
        responsibilities: ['Council Meetings', 'Parliamentary Procedures', 'Official Communications', 'Protocol']
    },
    vice: {
        name: 'Vice President',
        icon: '👤',
        description: 'Assists the president and oversees special projects and initiatives',
        responsibilities: ['Presidential Assistance', 'Special Projects', 'Initiative Oversight', 'Coordination']
    }
};

// Election candidates
const ELECTION_CANDIDATES = [
    {
        id: 'sarah-president',
        name: 'Sarah Johnson',
        position: 'President',
        image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=300',
        manifesto: 'Committed to improving student facilities and academic support services.',
        votes: 1247
    },
    {
        id: 'michael-vp',
        name: 'Michael Chen',
        position: 'Vice President',
        image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=300',
        manifesto: 'Focused on enhancing student engagement and campus activities.',
        votes: 1156
    },
    {
        id: 'aisha-secretary',
        name: 'Aisha Mohammed',
        position: 'Secretary',
        image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=300',
        manifesto: 'Dedicated to transparent communication and efficient administration.',
        votes: 1089
    }
];

// Mobile Menu Toggle
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const navMenu = document.getElementById('navMenu');

mobileMenuBtn.addEventListener('click', function() {
    navMenu.classList.toggle('active');
    
    if (navMenu.classList.contains('active')) {
        mobileMenuBtn.innerHTML = '✕';
    } else {
        mobileMenuBtn.innerHTML = '☰';
    }
});

// Navigation functionality
const navLinks = document.querySelectorAll('.nav-link');
navLinks.forEach(link => {
    link.addEventListener('click', function() {
        navMenu.classList.remove('active');
        mobileMenuBtn.innerHTML = '☰';
        
        navLinks.forEach(l => l.classList.remove('active'));
        this.classList.add('active');
    });
});

// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Header scroll effect
window.addEventListener('scroll', function() {
    const header = document.querySelector('.header');
    if (window.scrollY > 100) {
        header.style.background = 'rgba(255, 255, 255, 0.98)';
        header.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
    } else {
        header.style.background = 'rgba(255, 255, 255, 0.95)';
        header.style.boxShadow = 'none';
    }
});

// Utility functions
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Close modal when clicking outside
window.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
});

// FIXED Login form functionality
function updateLoginForm() {
    const loginType = document.getElementById('loginType').value;
    const clubSelectGroup = document.getElementById('clubSelectGroup');
    const branchSelectGroup = document.getElementById('branchSelectGroup');
    
    // Hide all groups first
    clubSelectGroup.style.display = 'none';
    branchSelectGroup.style.display = 'none';
    
    // Reset required attributes
    document.getElementById('clubSelect').required = false;
    document.getElementById('branchSelect').required = false;
    
    if (loginType === 'club_president') {
        clubSelectGroup.style.display = 'block';
        document.getElementById('clubSelect').required = true;
    } else if (loginType === 'branch_member') {
        branchSelectGroup.style.display = 'block';
        document.getElementById('branchSelect').required = true;
    }
}

// FIXED Authentication system
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const loginType = document.getElementById('loginType').value;
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    const selectedClub = document.getElementById('clubSelect').value;
    const selectedBranch = document.getElementById('branchSelect').value;
    
    console.log('Login attempt:', { loginType, username, password }); // Debug log
    
    // Validate credentials
    if (SYSTEM_USERS[username] && SYSTEM_USERS[username].password === password) {
        const user = SYSTEM_USERS[username];
        
        console.log('User found:', user); // Debug log
        
        // Check if role matches login type
        if (user.role !== loginType) {
            showNotification('Invalid login type for this user', 'error');
            return;
        }
        
        // For club presidents, check if they selected the correct club
        if (loginType === 'club_president') {
            if (!selectedClub) {
                showNotification('Please select your club', 'error');
                return;
            }
            if (user.club !== selectedClub) {
                showNotification('You are not the president of the selected club', 'error');
                return;
            }
        }
        
        // For branch members, check if they selected the correct branch
        if (loginType === 'branch_member') {
            if (!selectedBranch) {
                showNotification('Please select your branch', 'error');
                return;
            }
            if (user.branch !== selectedBranch) {
                showNotification('You are not assigned to the selected branch', 'error');
                return;
            }
        }
        
        // Successful login
        currentUser = {
            username: username,
            name: user.name,
            role: user.role,
            club: user.club || null,
            branch: user.branch || null,
            department: user.department || null,
            permissions: user.permissions
        };
        
        console.log('Login successful:', currentUser); // Debug log
        
        showNotification(`Welcome, ${user.name}!`, 'success');
        closeModal('loginModal');
        updateUIForLoggedInUser();
        showRoleBasedContent();
        
        // Save login state
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Clear form
        document.getElementById('loginForm').reset();
        updateLoginForm(); // Reset form visibility
        
    } else {
        console.log('Invalid credentials'); // Debug log
        showNotification('Invalid username or password', 'error');
    }
});

// Registration system
document.getElementById('registerForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const fullName = document.getElementById('regFullName').value;
    const email = document.getElementById('regEmail').value;
    const studentId = document.getElementById('regStudentId').value;
    const password = document.getElementById('regPassword').value;
    const confirmPassword = document.getElementById('regConfirmPassword').value;
    const department = document.getElementById('regDepartment').value;
    
    // Validate passwords match
    if (password !== confirmPassword) {
        showNotification('Passwords do not match', 'error');
        return;
    }
    
    // Check if student ID already exists
    if (SYSTEM_USERS[studentId]) {
        showNotification('Student ID already registered', 'error');
        return;
    }
    
    // Create new user
    SYSTEM_USERS[studentId] = {
        password: password,
        role: USER_ROLES.STUDENT,
        name: fullName,
        email: email,
        department: department,
        permissions: ['vote', 'submit_complaint', 'join_clubs']
    };
    
    showNotification('Registration successful! You can now login.', 'success');
    closeModal('registerModal');
    
    // Clear form
    document.getElementById('registerForm').reset();
});

// Update UI for logged in user
function updateUIForLoggedInUser() {
    const userInfo = document.getElementById('userInfo');
    const authButtons = document.getElementById('authButtons');
    const userName = document.getElementById('userName');
    const userRole = document.getElementById('userRole');
    
    if (currentUser) {
        userName.textContent = currentUser.name;
        userRole.textContent = getRoleDisplayName(currentUser.role);
        
        userInfo.style.display = 'flex';
        authButtons.style.display = 'none';
    } else {
        userInfo.style.display = 'none';
        authButtons.style.display = 'flex';
    }
}

function getRoleDisplayName(role) {
    switch (role) {
        case USER_ROLES.ADMIN:
            return 'System Admin';
        case USER_ROLES.COUNCIL_PRESIDENT:
            return 'Council President';
        case USER_ROLES.BRANCH_MEMBER:
            return 'Branch Member';
        case USER_ROLES.CLUB_PRESIDENT:
            return 'Club President';
        case USER_ROLES.STUDENT:
            return 'Student';
        default:
            return 'User';
    }
}

// FIXED Show role-based content
function showRoleBasedContent() {
    // Hide all dashboards first
    document.getElementById('adminDashboard').style.display = 'none';
    document.getElementById('presidentDashboard').style.display = 'none';
    document.getElementById('branchDashboard').style.display = 'none';
    document.getElementById('clubDashboard').style.display = 'none';
    
    if (!currentUser) return;
    
    console.log('Showing dashboard for role:', currentUser.role); // Debug log
    
    switch (currentUser.role) {
        case USER_ROLES.ADMIN:
            document.getElementById('adminDashboard').style.display = 'block';
            break;
        case USER_ROLES.COUNCIL_PRESIDENT:
            document.getElementById('presidentDashboard').style.display = 'block';
            break;
        case USER_ROLES.BRANCH_MEMBER:
            document.getElementById('branchDashboard').style.display = 'block';
            const branchInfo = BRANCHES_DATA[currentUser.branch];
            if (branchInfo) {
                document.getElementById('branchDashboardTitle').textContent = `${branchInfo.name} Dashboard`;
            }
            break;
        case USER_ROLES.CLUB_PRESIDENT:
            document.getElementById('clubDashboard').style.display = 'block';
            const clubName = CLUBS_DATA[currentUser.club]?.name || 'Club';
            document.getElementById('clubDashboardTitle').textContent = `${clubName} President Dashboard`;
            break;
    }
}

// Logout functionality
function logout() {
    currentUser = null;
    hasVoted = false;
    
    updateUIForLoggedInUser();
    showRoleBasedContent();
    
    // Clear saved state
    localStorage.removeItem('currentUser');
    
    // Reset vote buttons
    const voteButtons = document.querySelectorAll('.btn-vote');
    voteButtons.forEach(button => {
        button.textContent = 'Vote';
        button.disabled = false;
        button.style.background = '#4A67C8';
    });
    
    showNotification('Logged out successfully', 'info');
}

// Voting system
function vote(candidateId) {
    if (!currentUser) {
        showNotification('Please sign in to vote', 'error');
        openModal('loginModal');
        return;
    }
    
    if (!currentUser.permissions.includes('vote')) {
        showNotification('You do not have permission to vote', 'error');
        return;
    }
    
    if (!electionActive) {
        showNotification('Election is currently closed', 'warning');
        return;
    }
    
    if (hasVoted) {
        showNotification('You have already voted in this election', 'warning');
        return;
    }
    
    // Store candidate for after ID verification
    selectedCandidateForVoting = candidateId;
    
    // Check if ID is already verified
    if (isIdVerified) {
        processVote(candidateId);
    } else {
        openModal('idVerificationModal');
    }
}

// ID Verification for voting
document.getElementById('idVerificationForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const universityId = document.getElementById('universityId').value;
    const idPhoto = document.getElementById('idPhoto').files[0];
    
    if (!universityId || !idPhoto) {
        showNotification('Please provide both University ID and ID photo', 'error');
        return;
    }
    
    // Validate University ID format
    if (!universityId.match(/^DBU\d{7}$/)) {
        showNotification('Invalid University ID format. Use format: DBU1234567', 'error');
        return;
    }
    
    // Check if this ID has already voted
    const votedIds = JSON.parse(localStorage.getItem('votedUniversityIds') || '[]');
    if (votedIds.includes(universityId)) {
        showNotification('This University ID has already been used to vote', 'error');
        return;
    }
    
    showNotification('Verifying your ID...', 'info');
    
    setTimeout(() => {
        // Simulate ID verification process
        isIdVerified = true;
        
        // Store the verified ID
        votedIds.push(universityId);
        localStorage.setItem('votedUniversityIds', JSON.stringify(votedIds));
        
        showNotification('ID verified successfully! Processing your vote...', 'success');
        closeModal('idVerificationModal');
        
        // Process the vote
        if (selectedCandidateForVoting) {
            setTimeout(() => processVote(selectedCandidateForVoting), 1000);
        }
    }, 2000);
});

function processVote(candidateId) {
    hasVoted = true;
    showNotification('Your vote has been recorded successfully!', 'success');
    
    updateVoteResults(candidateId);
    
    const voteButtons = document.querySelectorAll('.btn-vote');
    voteButtons.forEach(button => {
        button.textContent = 'Voted';
        button.disabled = true;
        button.style.background = '#10B981';
    });
    
    // Save voting state
    localStorage.setItem('hasVoted', 'true');
    localStorage.setItem('isIdVerified', 'true');
}

// File upload preview
document.getElementById('idPhoto').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const preview = document.getElementById('uploadPreview');
    const placeholder = document.querySelector('.upload-placeholder');
    const previewImage = document.getElementById('previewImage');
    const fileName = document.getElementById('fileName');
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImage.src = e.target.result;
            fileName.textContent = file.name;
            placeholder.style.display = 'none';
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
});

function updateVoteResults(candidateId) {
    // Find and update the voted candidate
    const candidate = ELECTION_CANDIDATES.find(c => c.id === candidateId);
    if (candidate) {
        candidate.votes += 1;
    }
    
    // Update other candidates with random votes for simulation
    ELECTION_CANDIDATES.forEach(candidate => {
        if (candidate.id !== candidateId) {
            candidate.votes += Math.floor(Math.random() * 3);
        }
    });
    
    loadElectionResults();
}

// Club joining system
function joinClub(clubKey) {
    if (!currentUser) {
        showNotification('Please sign in to join a club', 'error');
        openModal('loginModal');
        return;
    }
    
    if (!currentUser.permissions.includes('join_clubs')) {
        showNotification('You do not have permission to join clubs', 'error');
        return;
    }
    
    selectedClubForJoining = clubKey;
    const club = CLUBS_DATA[clubKey];
    document.getElementById('clubJoinTitle').textContent = `Join ${club.name}`;
    openModal('clubJoinModal');
}

// Club join request submission
document.getElementById('clubJoinForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const universityId = document.getElementById('joinUniversityId').value;
    const reason = document.getElementById('joinReason').value;
    const experience = document.getElementById('joinExperience').value;
    
    // Validate University ID format
    if (!universityId.match(/^DBU\d{7}$/)) {
        showNotification('Invalid University ID format. Use format: DBU1234567', 'error');
        return;
    }
    
    const joinRequest = {
        id: `JOIN-${joinRequestCounter++}`,
        clubKey: selectedClubForJoining,
        studentName: currentUser.name,
        studentUsername: currentUser.username,
        universityId: universityId,
        reason: reason,
        experience: experience,
        status: 'pending',
        submittedAt: new Date().toISOString()
    };
    
    // Add to club's pending requests
    CLUBS_DATA[selectedClubForJoining].pendingRequests.push(joinRequest);
    
    // Save to localStorage
    localStorage.setItem(`joinRequest_${joinRequest.id}`, JSON.stringify(joinRequest));
    
    showNotification(`Join request submitted to ${CLUBS_DATA[selectedClubForJoining].name}! You will be notified once reviewed.`, 'success');
    closeModal('clubJoinModal');
    
    // Clear form
    this.reset();
});

// Branch functions - Enhanced for club management
function viewBranchClubs() {
    if (!hasPermission('submit_reports')) return;
    
    const branchClubs = Object.entries(CLUBS_DATA).filter(([key, club]) => 
        club.branch === currentUser.branch
    );
    
    if (branchClubs.length === 0) {
        showNotification('No clubs assigned to your branch', 'info');
        return;
    }
    
    const clubNames = branchClubs.map(([key, club]) => club.name).join(', ');
    showNotification(`Your branch manages: ${clubNames}`, 'info');
}

function reviewJoinRequests() {
    if (!hasPermission('submit_reports')) return;
    
    const branchClubs = Object.entries(CLUBS_DATA).filter(([key, club]) => 
        club.branch === currentUser.branch
    );
    
    let totalRequests = 0;
    branchClubs.forEach(([key, club]) => {
        totalRequests += club.pendingRequests.length;
    });
    
    if (totalRequests === 0) {
        showNotification('No pending join requests for your branch clubs', 'info');
    } else {
        showNotification(`${totalRequests} pending join requests for your branch clubs`, 'info');
    }
}

function manageClubReports() {
    if (!hasPermission('submit_reports')) return;
    showNotification('Opening club reports management for your branch...', 'info');
}

function approveClubProposals() {
    if (!hasPermission('submit_reports')) return;
    showNotification('Opening club proposal approval interface for your branch...', 'info');
}

// Club President functions - Enhanced
function reviewMemberRequests() {
    if (!hasPermission('manage_club_members')) return;
    
    const club = CLUBS_DATA[currentUser.club];
    if (!club) {
        showNotification('Club not found', 'error');
        return;
    }
    
    const pendingRequests = club.pendingRequests.filter(req => req.status === 'pending');
    
    if (pendingRequests.length === 0) {
        showNotification('No pending join requests for your club', 'info');
    } else {
        showNotification(`${pendingRequests.length} pending join requests for ${club.name}`, 'info');
        // Here you would typically show a detailed interface for reviewing requests
    }
}

// President functions - Enhanced with full control
function viewAllBranches() {
    if (!hasPermission('manage_all_branches')) return;
    
    const branchList = Object.values(BRANCHES_DATA).map(branch => branch.name).join(', ');
    showNotification(`Managing all branches: ${branchList}`, 'info');
}

function approveBranchReports() {
    if (!hasPermission('approve_all')) return;
    
    // Count pending reports from all branches
    let pendingReports = Math.floor(Math.random() * 15) + 5; // Simulate pending reports
    showNotification(`${pendingReports} branch reports pending your approval`, 'info');
}

function approveClubActivities() {
    if (!hasPermission('approve_all')) return;
    
    // Count pending club activities across all branches
    let pendingActivities = Object.values(CLUBS_DATA).reduce((total, club) => 
        total + club.pendingRequests.length, 0
    );
    
    showNotification(`${pendingActivities} club activities pending your approval across all branches`, 'info');
}

// Admin functions - Enhanced with full system control
function viewAllUsers() {
    if (!hasPermission('all')) return;
    
    const totalUsers = Object.keys(SYSTEM_USERS).length;
    showNotification(`Managing ${totalUsers} total system users across all roles`, 'info');
}

function manageElections() {
    if (!hasPermission('all')) return;
    
    const totalVotes = ELECTION_CANDIDATES.reduce((sum, candidate) => sum + candidate.votes, 0);
    showNotification(`Election management: ${totalVotes} total votes cast`, 'info');
}

// Enhanced logout to clear verification state
function logout() {
    currentUser = null;
    hasVoted = false;
    isIdVerified = false;
    selectedCandidateForVoting = null;
    selectedClubForJoining = null;
    
    updateUIForLoggedInUser();
    showRoleBasedContent();
    
    // Clear saved state
    localStorage.removeItem('currentUser');
    localStorage.removeItem('isIdVerified');
    
    // Reset vote buttons
    const voteButtons = document.querySelectorAll('.btn-vote');
    voteButtons.forEach(button => {
        button.textContent = 'Vote';
        button.disabled = false;
        button.style.background = '#4A67C8';
    });
    
    showNotification('Logged out successfully', 'info');
}

// Load saved verification state
function loadSavedStates() {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        try {
            currentUser = JSON.parse(savedUser);
            updateUIForLoggedInUser();
            showRoleBasedContent();
        } catch (e) {
            console.error('Error restoring user session:', e);
            localStorage.removeItem('currentUser');
        }
    }
    
    // Load saved voting state
    const savedVotingState = localStorage.getItem('hasVoted');
    if (savedVotingState === 'true') {
        hasVoted = true;
        
        const voteButtons = document.querySelectorAll('.btn-vote');
        voteButtons.forEach(button => {
            button.textContent = 'Voted';
            button.disabled = true;
            button.style.background = '#10B981';
        });
    }
    
    // Load ID verification state
    const savedIdVerification = localStorage.getItem('isIdVerified');
    if (savedIdVerification === 'true') {
        isIdVerified = true;
    }
}

function updateVoteResults(candidateId) {
    // Find and update the voted candidate
    const candidate = ELECTION_CANDIDATES.find(c => c.id === candidateId);
    if (candidate) {
        candidate.votes += 1;
    }
    
    // Update other candidates with random votes for simulation
    ELECTION_CANDIDATES.forEach(candidate => {
        if (candidate.id !== candidateId) {
            candidate.votes += Math.floor(Math.random() * 3);
        }
    });
    
    loadElectionResults();
}

// Complaint system
document.getElementById('complaintForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    if (!currentUser) {
        showNotification('Please sign in to submit a complaint', 'error');
        openModal('loginModal');
        return;
    }
    
    if (!currentUser.permissions.includes('submit_complaint')) {
        showNotification('You do not have permission to submit complaints', 'error');
        return;
    }
    
    const formData = new FormData(this);
    const complaintData = {
        id: `DBU-${complaintCounter++}`,
        studentId: formData.get('studentId'),
        category: formData.get('category'),
        priority: formData.get('priority'),
        description: formData.get('description'),
        evidence: formData.get('evidence'),
        status: 'submitted',
        submittedAt: new Date().toISOString(),
        submittedBy: currentUser.username
    };
    
    showNotification('Submitting your complaint...', 'info');
    
    setTimeout(() => {
        localStorage.setItem(`complaint_${complaintData.id}`, JSON.stringify(complaintData));
        showNotification(`Complaint submitted successfully! Your tracking ID is: ${complaintData.id}`, 'success');
        this.reset();
    }, 2000);
});

function trackComplaint() {
    const trackingId = document.getElementById('trackingId').value.trim();
    
    if (!trackingId) {
        showNotification('Please enter a complaint ID', 'warning');
        return;
    }
    
    showNotification('Looking up complaint...', 'info');
    
    setTimeout(() => {
        const complaint = localStorage.getItem(`complaint_${trackingId}`);
        
        if (complaint) {
            const complaintData = JSON.parse(complaint);
            displayComplaintStatus(complaintData);
            showNotification('Complaint found! Status updated below.', 'success');
        } else {
            // For demo purposes, show generic status
            displayGenericComplaintStatus();
            showNotification('Complaint status retrieved', 'success');
        }
    }, 1500);
}

function displayComplaintStatus(complaint) {
    const statusElement = document.getElementById('complaintStatus');
    const timeline = document.getElementById('statusTimeline');
    
    timeline.innerHTML = `
        <div class="timeline-item completed">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <h4>Complaint Submitted</h4>
                <p>${new Date(complaint.submittedAt).toLocaleString()}</p>
            </div>
        </div>
        <div class="timeline-item completed">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <h4>Under Review</h4>
                <p>Being reviewed by relevant department</p>
            </div>
        </div>
        <div class="timeline-item active">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <h4>Investigation in Progress</h4>
                <p>Currently being investigated</p>
            </div>
        </div>
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <h4>Resolution</h4>
                <p>Pending</p>
            </div>
        </div>
    `;
    
    statusElement.style.display = 'block';
}

function displayGenericComplaintStatus() {
    const statusElement = document.getElementById('complaintStatus');
    const timeline = document.getElementById('statusTimeline');
    
    timeline.innerHTML = `
        <div class="timeline-item completed">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <h4>Complaint Submitted</h4>
                <p>Dec 1, 2024 - 2:30 PM</p>
            </div>
        </div>
        <div class="timeline-item completed">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <h4>Under Review</h4>
                <p>Dec 2, 2024 - 9:15 AM</p>
            </div>
        </div>
        <div class="timeline-item active">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <h4>Investigation in Progress</h4>
                <p>Dec 3, 2024 - 11:00 AM</p>
            </div>
        </div>
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <h4>Resolution</h4>
                <p>Pending</p>
            </div>
        </div>
    `;
    
    statusElement.style.display = 'block';
}

// Load election candidates and results
function loadElectionCandidates() {
    const candidatesGrid = document.getElementById('candidatesGrid');
    
    candidatesGrid.innerHTML = ELECTION_CANDIDATES.map(candidate => `
        <div class="candidate-card">
            <div class="candidate-image">
                <img src="${candidate.image}" alt="${candidate.name}">
            </div>
            <div class="candidate-info">
                <h3>${candidate.name}</h3>
                <p class="position">${candidate.position}</p>
                <p class="manifesto">${candidate.manifesto}</p>
                <button class="btn-vote" onclick="vote('${candidate.id}')">Vote</button>
            </div>
        </div>
    `).join('');
}

function loadElectionResults() {
    const resultsGrid = document.getElementById('resultsGrid');
    const totalVotes = ELECTION_CANDIDATES.reduce((sum, candidate) => sum + candidate.votes, 0);
    
    resultsGrid.innerHTML = ELECTION_CANDIDATES.map(candidate => {
        const percentage = totalVotes > 0 ? Math.round((candidate.votes / totalVotes) * 100) : 0;
        
        return `
            <div class="result-item">
                <div class="result-header">
                    <span>${candidate.position}</span>
                    <span class="vote-count">${candidate.votes.toLocaleString()} votes</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${percentage}%"></div>
                </div>
                <p>${candidate.name} - ${percentage}%</p>
            </div>
        `;
    }).join('');
}

// Load clubs
function loadClubs() {
    const clubsGrid = document.getElementById('clubsGrid');
    
    clubsGrid.innerHTML = Object.entries(CLUBS_DATA).map(([key, club]) => `
        <div class="club-card">
            <div class="club-icon">${club.icon}</div>
            <h3>${club.name}</h3>
            <p>${club.description}</p>
            <div class="club-stats">
                <span>${club.members} members</span>
                <span>${club.events} events</span>
            </div>
            <button class="btn-join" onclick="joinClub('${key}')">Join Club</button>
        </div>
    `).join('');
}

function joinClub(clubKey) {
    if (!currentUser) {
        showNotification('Please sign in to join a club', 'error');
        openModal('loginModal');
        return;
    }
    
    if (!currentUser.permissions.includes('join_clubs')) {
        showNotification('You do not have permission to join clubs', 'error');
        return;
    }
    
    const club = CLUBS_DATA[clubKey];
    showNotification(`Successfully joined ${club.name}!`, 'success');
}

// Admin functions
function viewAllUsers() {
    if (!hasPermission('all')) return;
    showNotification('Loading user management interface...', 'info');
}

function manageRoles() {
    if (!hasPermission('all')) return;
    showNotification('Opening role management...', 'info');
}

function resetPasswords() {
    if (!hasPermission('all')) return;
    showNotification('Password reset functionality activated', 'info');
}

function systemSettings() {
    if (!hasPermission('all')) return;
    showNotification('Opening system settings...', 'info');
}

function startElection() {
    if (!hasPermission('all') && !hasPermission('election_control')) return;
    electionActive = true;
    document.getElementById('electionStatus').textContent = 'Voting Open';
    document.getElementById('electionStatus').className = 'status-badge active';
    showNotification('Election has been started', 'success');
}

function endElection() {
    if (!hasPermission('all') && !hasPermission('election_control')) return;
    electionActive = false;
    document.getElementById('electionStatus').textContent = 'Voting Closed';
    document.getElementById('electionStatus').className = 'status-badge closed';
    showNotification('Election has been closed', 'info');
}

function viewElectionResults() {
    if (!hasPermission('all') && !hasPermission('election_control')) return;
    showNotification('Displaying detailed election results...', 'info');
}

function manageElections() {
    if (!hasPermission('all')) return;
    showNotification('Opening election management interface...', 'info');
}

function backupData() {
    if (!hasPermission('all')) return;
    showNotification('Creating system backup...', 'info');
}

function viewLogs() {
    if (!hasPermission('all')) return;
    showNotification('Loading system logs...', 'info');
}

function generateReports() {
    if (!hasPermission('all')) return;
    showNotification('Generating system reports...', 'info');
}

function dataAnalytics() {
    if (!hasPermission('all')) return;
    showNotification('Loading data analytics dashboard...', 'info');
}

// President functions
function viewAllBranches() {
    if (!hasPermission('manage_all_branches')) return;
    showNotification('Loading all branch information...', 'info');
}

function approveBranchReports() {
    if (!hasPermission('approve_all')) return;
    showNotification('Opening branch report approval interface...', 'info');
}

function assignBranchTasks() {
    if (!hasPermission('manage_all_branches')) return;
    showNotification('Opening task assignment interface...', 'info');
}

function branchPerformance() {
    if (!hasPermission('manage_all_branches')) return;
    showNotification('Loading branch performance metrics...', 'info');
}

function approveProposals() {
    if (!hasPermission('approve_all')) return;
    showNotification('Opening proposal approval interface...', 'info');
}

function approveClubActivities() {
    if (!hasPermission('approve_all')) return;
    showNotification('Opening club activity approval interface...', 'info');
}

function budgetApprovals() {
    if (!hasPermission('approve_all')) return;
    showNotification('Opening budget approval interface...', 'info');
}

function eventApprovals() {
    if (!hasPermission('approve_all')) return;
    showNotification('Opening event approval interface...', 'info');
}

function strategicPlanning() {
    if (!hasPermission('manage_all_branches')) return;
    showNotification('Opening strategic planning interface...', 'info');
}

function policyMaking() {
    if (!hasPermission('manage_all_branches')) return;
    showNotification('Opening policy making interface...', 'info');
}

function universityLiaison() {
    if (!hasPermission('manage_all_branches')) return;
    showNotification('Opening university liaison interface...', 'info');
}

function councilMeetings() {
    if (!hasPermission('manage_all_branches')) return;
    showNotification('Opening council meeting management...', 'info');
}

// Branch functions
function viewBranchTasks() {
    if (!hasPermission('submit_reports')) return;
    const branchName = BRANCHES_DATA[currentUser.branch]?.name || 'your branch';
    showNotification(`Loading ${branchName} tasks...`, 'info');
}

function submitBranchReport() {
    if (!hasPermission('submit_reports')) return;
    showNotification('Opening report submission interface...', 'info');
}

function manageBranchMembers() {
    if (!hasPermission('submit_reports')) return;
    showNotification('Opening branch member management...', 'info');
}

function branchActivities() {
    if (!hasPermission('submit_reports')) return;
    showNotification('Loading branch activities...', 'info');
}

function createProposal() {
    if (!hasPermission('create_proposals')) return;
    showNotification('Opening proposal creation interface...', 'info');
}

function viewProposalStatus() {
    if (!hasPermission('create_proposals')) return;
    showNotification('Loading proposal status...', 'info');
}

function monthlyReports() {
    if (!hasPermission('submit_reports')) return;
    showNotification('Loading monthly reports interface...', 'info');
}

function budgetRequests() {
    if (!hasPermission('create_proposals')) return;
    showNotification('Opening budget request interface...', 'info');
}

function coordinateWithOtherBranches() {
    if (!hasPermission('submit_reports')) return;
    showNotification('Opening inter-branch coordination interface...', 'info');
}

function studentFeedback() {
    if (!hasPermission('submit_reports')) return;
    showNotification('Loading student feedback interface...', 'info');
}

function branchMeetings() {
    if (!hasPermission('submit_reports')) return;
    showNotification('Opening branch meeting management...', 'info');
}

function communicationCenter() {
    if (!hasPermission('submit_reports')) return;
    showNotification('Opening communication center...', 'info');
}

// Club President functions
function viewClubMembers() {
    if (!hasPermission('manage_club_members')) return;
    const clubName = CLUBS_DATA[currentUser.club]?.name || 'your club';
    showNotification(`Loading ${clubName} member list...`, 'info');
}

function addClubMembers() {
    if (!hasPermission('manage_club_members')) return;
    showNotification('Opening member addition interface...', 'info');
}

function memberActivities() {
    if (!hasPermission('manage_club_members')) return;
    showNotification('Loading member activity reports...', 'info');
}

function memberReports() {
    if (!hasPermission('manage_club_members')) return;
    showNotification('Loading member reports...', 'info');
}

function createClubEvent() {
    if (!hasPermission('create_events')) return;
    showNotification('Opening event creation interface...', 'info');
}

function manageClubEvents() {
    if (!hasPermission('create_events')) return;
    showNotification('Loading event management interface...', 'info');
}

function eventReports() {
    if (!hasPermission('create_events')) return;
    showNotification('Loading event reports...', 'info');
}

function eventApprovalStatus() {
    if (!hasPermission('create_events')) return;
    showNotification('Loading event approval status...', 'info');
}

function requestClubResources() {
    if (!hasPermission('club_reports')) return;
    showNotification('Opening resource request form...', 'info');
}

function clubBudgetManagement() {
    if (!hasPermission('club_reports')) return;
    showNotification('Loading budget management interface...', 'info');
}

function submitClubReports() {
    if (!hasPermission('club_reports')) return;
    showNotification('Opening report submission interface...', 'info');
}

function clubProposals() {
    if (!hasPermission('club_reports')) return;
    showNotification('Opening club proposal interface...', 'info');
}

// Permission checking
function hasPermission(permission) {
    if (!currentUser) {
        showNotification('Please sign in to access this feature', 'error');
        return false;
    }
    
    if (currentUser.permissions.includes('all') || currentUser.permissions.includes(permission)) {
        return true;
    }
    
    showNotification('You do not have permission to access this feature', 'error');
    return false;
}

// Notification system
function showNotification(message, type = 'info') {
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    let backgroundColor, icon;
    switch (type) {
        case 'success':
            backgroundColor = '#10B981';
            icon = '✓';
            break;
        case 'error':
            backgroundColor = '#EF4444';
            icon = '✕';
            break;
        case 'warning':
            backgroundColor = '#F59E0B';
            icon = '⚠';
            break;
        default:
            backgroundColor = '#3B82F6';
            icon = 'ℹ';
    }
    
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">${icon}</span>
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">✕</button>
        </div>
    `;
    
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${backgroundColor};
        color: white;
        padding: 16px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 10000;
        max-width: 350px;
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.3s ease;
    `;
    
    notification.querySelector('.notification-content').style.cssText = `
        display: flex;
        align-items: center;
        gap: 8px;
    `;
    
    notification.querySelector('.notification-close').style.cssText = `
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        font-size: 14px;
        margin-left: auto;
        padding: 4px;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// Keyboard navigation
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        if (navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
            mobileMenuBtn.innerHTML = '☰';
        }
        
        const openModals = document.querySelectorAll('.modal[style*="block"]');
        openModals.forEach(modal => {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    }
    
    if (e.key === 'Enter' && e.target.tagName === 'BUTTON') {
        e.target.click();
    }
});

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    console.log('DBU Student Council System initializing...'); // Debug log
    
    // Load all saved states
    loadSavedStates();
    
    // Load content
    loadElectionCandidates();
    loadElectionResults();
    loadClubs();
    
    console.log('DBU Student Council System initialized! 🗳️📋');
    console.log('Demo Accounts:');
    console.log('Admin: admin001 / admin123');
    console.log('Council President: president001 / president123');
    console.log('Branch (Academic): academic001 / academic123');
    console.log('Club President (Debate): club_debate001 / debate123');
    console.log('Student: DBU2024001 / student123');
});